export const baseUrl = {
    url: process.env.REACT_APP_BASE_URL,
    token: process.env.REACT_APP_TOKEN
};
