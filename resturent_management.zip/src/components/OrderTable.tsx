import React, {useEffect, useState} from 'react';
import {DataTable, DataTableFilterMeta} from 'primereact/datatable';
import {Column, ColumnFilterElementTemplateOptions} from 'primereact/column';
import {OrderData} from "../type";
import useFetch from "../hook/UseFetch";
import {baseUrl} from "../utilis/webinfo";
import {Tag} from "primereact/tag";
import {FilterMatchMode} from "primereact/api";
import {Dropdown, DropdownChangeEvent} from "primereact/dropdown";
import {log} from "node:util";
import {ProgressSpinner} from "primereact/progressspinner";
import {MultiSelectChangeEvent} from "primereact/multiselect";


interface FiltersData extends DataTableFilterMeta {
    order_number: { value: string; matchMode: FilterMatchMode };
    order_status_id: { value: string; matchMode: FilterMatchMode };
    "order_type.name": { value: string; matchMode: FilterMatchMode };
    cooking_complete_status: { value: string; matchMode: FilterMatchMode };
    payment_status: { value: string; matchMode: FilterMatchMode };
}

interface OrderTypes {
    id: number;
    name: string;
    note: string;
    min_order: number;
}

export default function OrderTable() {
    const [isLoading, setIsLoading] = useState(true);
    const [hasError, setHasError] = useState(false);
    const [orderData, setOrderData] = useState<OrderData[]>([]);
    const [filters, setFilters] = useState<FiltersData>({
        order_number: {value: '', matchMode: FilterMatchMode.CONTAINS},
        "order_status_id": {value: '', matchMode: FilterMatchMode.EQUALS},
        "order_type.name": {value: '', matchMode: FilterMatchMode.STARTS_WITH},
        "cooking_complete_status": {value: '', matchMode: FilterMatchMode.IN},
        payment_status: {value: '', matchMode: FilterMatchMode.EQUALS},
    });
    const [orderTypes, setOrderTypes] = useState<OrderTypes[]>([{id: 1, name:'',note: '', min_order: 1}])


    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch(`${baseUrl.url}/api/order?page=0&size=100`, {headers: {Authorization: `bearer ${baseUrl.token}`}});
                const orderTypeDropdownRes = await fetch(`${baseUrl.url}/api/order_type?page=0&size=100`, {headers: {Authorization: `bearer ${baseUrl.token}`}});
                const data = await response.json();
                const  orderTypesData = await orderTypeDropdownRes.json();

                setOrderData(data?.data?.items);
                setOrderTypes(orderTypesData?.data?.items);
            } catch (error) {
                setHasError(true);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    if (isLoading) {
        return <div className={'flex h-screen justify-content-center align-content-center'}>
            <ProgressSpinner/>
        </div>
    }

    const renderHeader = () => {
        return (
            <div className="flex justify-content-end">

            </div>
        );
    };

    const getOrderStatusSeverity = (status: number) => {
        switch (status) {
            case 1:
                return 'warning';

            case 2:
                return 'success';

            case 3:
                return 'danger';


        }
    };
    const getOrderStatusText = (status: number) => {
        switch (status) {
            case 1:
                return 'Processing';

            case 2:
                return 'Completed';

            case 3:
                return 'Cancelled';


        }
    };
    const getFilterUrl = (status: any) => {
        switch (status) {
            case 1:
                return 'Processing';

            case 2:
                return 'Completed';

            case 3:
                return 'Cancelled';


        }
    };


    const orderStatusTemplate = (rowData: OrderData) => {
        return <Tag
            severity={getOrderStatusSeverity(rowData?.order_status_id)}>{getOrderStatusText(rowData?.order_status_id)}</Tag>;
    }

    const cookingCompleteTemplate = (rowData: OrderData) => {

        return rowData.cooking_complete_status === 1 ? <Tag severity={'success'}>Complete</Tag> :
            <Tag severity={'danger'}>Pending</Tag>;
    }

    const paymentStatusTemplate = (rowData: OrderData) => {

        return rowData.payment_status === 1 ? <Tag severity={'success'}>Complete</Tag> :
            <Tag severity={'warning'}>Pending</Tag>;
    }


    const orderStatusRowFilterTemplate = (options: ColumnFilterElementTemplateOptions) => {
        console.log(options)
        return (
            <Dropdown value={options?.value}  options={orderTypes?.map((type: any) => ({id: type?.id, name: type?.name}))}
                      optionLabel="name"
                      placeholder="Select order type"
                      className="w-full md:w-14rem"

                      onChange={(e: DropdownChangeEvent) => {
                          console.log('options:', options)
                          console.log('event:', e)
                          options.value = e.value
                          options.filterApplyCallback(e.value)
                      }}

            />

        );
    };


    const handleOnFilter = async ({filters}: DataTableFilterMeta) => {

        const {order_number} = filters as any;

        console.log(filters);


        const filterUrl = Object.entries(filters).reduce((acc: string, [key, value]) => {
            if (!value.value) return acc;
            if (key === "order_number") {
                return (`${acc}["${key}","LIKE","${value.value}"] `);

            } else {
                return (`${acc}["${key}","AND","${value.value}"] `);

            }
            // return acc
        }, "");

        try {
            const response = await fetch(`${baseUrl.url}/api/order?page=0&size=100&filters=[${filterUrl}]`, {headers: {Authorization: `bearer ${baseUrl.token}`}});
            const data = await response.json();
            setOrderData(data?.data?.items)
        } catch (error) {
            setHasError(true);
        } finally {
            setIsLoading(false);
        }
    }


    const header = renderHeader();

    return (
        <div className="card">
            <DataTable value={orderData} paginator rows={10} dataKey="id" filters={filters} filterDisplay="row"
                       onFilter={handleOnFilter}
                       header={header}
                       emptyMessage="No Order found.">
                <Column field="id" header="Order ID." style={{minWidth: '2rem'}}

                />
                <Column field="order_number" header="Order Number." filter filterPlaceholder="Search by Order number"
                        showFilterMenu={false} style={{minWidth: '12rem'}}/>
                <Column field="order_status_id" header="Order Status" body={orderStatusTemplate} filter
                        filterPlaceholder="Search by name" filterField={"order_status_id"}
                        style={{minWidth: '12rem'}}/>
                <Column field="order_type_id" header="Order Type" filter filterElement={orderStatusRowFilterTemplate} filterPlaceholder="Search by name"
                        style={{minWidth: '12rem'}}/>
                <Column field="cooking_complete_status" header="Cooking Complete status" body={cookingCompleteTemplate}
                        filter filterPlaceholder="Search by name" style={{minWidth: '12rem'}}/>
                <Column field="payment_status" header="Payment Status" body={paymentStatusTemplate}
                        filter filterPlaceholder="Search by name" style={{minWidth: '12rem'}}/>

            </DataTable>
        </div>
    );
}

