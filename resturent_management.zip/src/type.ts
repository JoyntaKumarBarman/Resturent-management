export interface OrderData {
    id: number;
    order_number: string;
    order_type_id: number;
    order_type: {
        "name": string;
    };
    cooking_complete_status: number;
    payment_status: number,
    order_status_id: number;
    order_status: {
        id: number;
        name: string;
    };


}